
package pilas;


public class ProductosCocina {
    private int codigo;
    private String nombre;
    private double precio;
    private boolean descuento;
    private double precioFinal;

   //CONSTRUCTOR
    public ProductosCocina(int codigo, String nombre, double precio, boolean descuento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.descuento = descuento;
    }
    
    public void calcularPrecio(){
        //double valDescuento;
        if (descuento==true){
            precioFinal=precio-precio*20/100;
        }else{
            precioFinal=precio;
        }
    }

    @Override
    public String toString() {
        return "ProductosCocina\n{" 
                + "Código=" + codigo + ", Nombre=" + nombre + ", Precio=" + precio 
                + ", Precio Final=" + precioFinal + '}';
    }
    
    
}
