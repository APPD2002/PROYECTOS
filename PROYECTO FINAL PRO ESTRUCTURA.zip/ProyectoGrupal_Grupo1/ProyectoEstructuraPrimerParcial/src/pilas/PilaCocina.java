
package pilas;


public class PilaCocina {
    ProductosCocina vectorPila[];
    int cima;//dato
    
/*
      ------  PRODUCTOS COCINA -----
    */    

//Construtor Productos Limpieza
    public PilaCocina(int tamanio){
        vectorPila=new ProductosCocina[tamanio];
        cima=-1;
    }
    
    //PuSh Productos Limpieza
    public void push (ProductosCocina dato){
    this.cima++;
    vectorPila[cima]=dato;
    }
    
    //PopProductos Limpieza
    public ProductosCocina pop(){
    ProductosCocina salir=vectorPila[cima];
    cima--;
    return salir;
    }
    
    //Conocer que elemento se encuentra cima
    public ProductosCocina cimaPila(){
    return vectorPila[cima];
    }
    

/*
    MÉTODOS GENERALES
    */

//sabe si la pila esta vacia
    public boolean estaVacia(){
    return cima== -1;
    }

    
    //Tamaño pila
    public int tamanioPila(){
    return vectorPila.length;
    }
    
    public boolean estaLlena(){
    return vectorPila.length-1==cima;
    
    }
}
