package lista.dinamica;

public class NodoCliente {
	
	public Cliente dato;// Donde almaceno la estructura de datos
	public NodoCliente siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoCliente(Cliente ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoCliente(Cliente palabras, NodoCliente nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}
}
