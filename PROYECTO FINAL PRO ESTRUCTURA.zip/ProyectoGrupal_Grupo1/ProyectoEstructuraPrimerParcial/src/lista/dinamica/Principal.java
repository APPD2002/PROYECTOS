package lista.dinamica;

import java.util.Scanner;

import javax.swing.JOptionPane;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListaCliente ocLista  = new ListaCliente();
		ListaProveedor opLista = new ListaProveedor();
		int menu=0;
		System.out.println("Software que permite ingresar cliente al sistema de forma dinamica");
		do {
			try {
		System.out.println("\n1.- Ingresar al Sistema los Clientes");
		System.out.println("2.- Ingresar al Sistema los Proveedores");
		System.out.println("3.- Salir");
		System.out.print("Su opcion es: ");
		Scanner sc = new Scanner (System.in);
		menu = sc.nextInt();
		if(menu ==1) {
		System.out.print("Digite el Cedula: ");
		int cedula = sc.nextInt();
		System.out.print("Digite el Nombre: ");
		String nombreCliente = sc.next();
		System.out.print("Digite el Apellido: ");
		String apellidoCliente = sc.next();
		System.out.print("Digite el Genero: ");
		String generoCliente = sc.next();
		System.out.print("Digite el Celular: ");
		int celularCliente = sc.nextInt();
		System.out.println("\n\t\tOPCIONES A REALIZAR");
		System.out.println("\n1.- Ingresar Cliente al Inicio de la Lista");
		System.out.println("2.- Ingresar Cliente al Final");
		System.out.println("3.- Eliminar Final de Lista ");
		System.out.println("4.- Mostrar Datos");
		//(int cedula, String nombres, String apellidos, String genero, int celular) {
		Cliente cliente = new Cliente(celularCliente, nombreCliente, apellidoCliente, generoCliente, celularCliente);
		System.out.print("Su opcion es: ");
		int menuCliente = sc.nextInt();
		switch (menuCliente) {
		case 1:
			try {
				System.out.println("Colocaldo al cliente al INICIO");
				ocLista.agregarInicioCliente(cliente);
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 2:
			try {
				System.out.println("Colocaldo al cliente al final");
				ocLista.agregarFinal(cliente);
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 3:
			try {
				System.out.println("Elimando Final de lista del Cliente Residencia");
				ocLista.eliminarFinalPersona();			

			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 4:
			ocLista.mostrarListaCliente();
			break;
			default:
				System.out.println("ERROR");
		}
	}
		else if(menu ==3) {
			Scanner prove = new Scanner (System.in);
			System.out.print("Digite el RUC: ");
			int ruc = prove.nextInt();
			System.out.print("Digite el Nombre: ");
			String nombreProveedor = prove.next();
			System.out.print("Digite el Apellido: ");
			String apellidoProveedor = prove.next();
			System.out.print("Digite el correo: ");
			String correoProveedor = prove.next();
			System.out.print("Digite el telefono: ");
			int telefonoProveedor =  prove.nextInt();
			System.out.println("\n\t\tOPCIONES A REALIZAR");
			System.out.println("\n1.- Ingresar Proveedor al Inicio de la Lista");
			System.out.println("2.- Ingresar Cliente al Final");
			System.out.println("3.- Eliminar Final de Lista ");
			System.out.println("4.- Mostrar Datos");
			System.out.println("5.- Buscar Cliente");
			//(int rUC, String nombres, String apellidos, String correo, int telefono) {
			Proveedor proveedor = new Proveedor(ruc, nombreProveedor, apellidoProveedor, correoProveedor, telefonoProveedor);
			int menuProveedor = sc.nextInt();
			switch (menuProveedor) {
			case 1:
				try {
					System.out.println("Colocaldo al Proveedor al INICIO");
					opLista.agregarInicioProveedor(proveedor);
				
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("Colocando al Proveedor al final");
					opLista.agregarFinal(proveedor);
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Elimando Final de lista del Proveedor Residencia");
					opLista.eliminarFinalPersona();

				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 4:
				opLista.mostrarListaProveedor();
				break;
			default: 
				System.out.println("ERROR!!!");
			}
		}
			
	} catch (Exception e) {

	}

} while (menu != 5);
}
}

