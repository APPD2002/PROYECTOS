package lista.dinamica;

public class Proveedor {
	
	private int RUC;
	private String nombres;
	private String apellidos;
	private String correo;
	private int telefono;
	
	public Proveedor(int rUC, String nombres, String apellidos, String correo, int telefono) {
		super();
		RUC = rUC;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.correo = correo;
		this.telefono = telefono;
	}
	
	public int getRUC() {
		return RUC;
	}
	public void setRUC(int rUC) {
		RUC = rUC;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "\nProveedor [RUC=" + RUC + ", nombres=" + nombres + ", apellidos=" + apellidos + ", correo=" + correo
				+ ", telefono=" + telefono + "]";
	}
	
	
}
