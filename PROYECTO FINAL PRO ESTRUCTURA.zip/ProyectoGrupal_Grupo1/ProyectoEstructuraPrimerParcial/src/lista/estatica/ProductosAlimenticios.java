package lista.estatica;

public class ProductosAlimenticios {
	private int idProductoAlimenticio;
	private String nombreAlimenticio;
	private String categoriaAlimenticio;
	private double precioAlimenticio;
	public ProductosAlimenticios(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio,
			double precioAlimenticio) {
		super();
		this.idProductoAlimenticio = idProductoAlimenticio;
		this.nombreAlimenticio = nombreAlimenticio;
		this.categoriaAlimenticio = categoriaAlimenticio;
		this.precioAlimenticio = precioAlimenticio;
	}
	public int getIdProductoAlimenticio() {
		return idProductoAlimenticio;
	}
	public void setIdProductoAlimenticio(int idProductoAlimenticio) {
		this.idProductoAlimenticio = idProductoAlimenticio;
	}
	public String getNombreAlimenticio() {
		return nombreAlimenticio;
	}
	public void setNombreAlimenticio(String nombreAlimenticio) {
		this.nombreAlimenticio = nombreAlimenticio;
	}
	public String getCategoriaAlimenticio() {
		return categoriaAlimenticio;
	}
	public void setCategoriaAlimenticio(String categoriaAlimenticio) {
		this.categoriaAlimenticio = categoriaAlimenticio;
	}
	public double getPrecioAlimenticio() {
		return precioAlimenticio;
	}
	public void setPrecioAlimenticio(double precioAlimenticio) {
		this.precioAlimenticio = precioAlimenticio;
	}
	@Override
	public String toString() {
		return "ProductosAlimenticios [idProductoAlimenticio=" + idProductoAlimenticio + ", nombreAlimenticio="
				+ nombreAlimenticio + ", categoriaAlimenticio=" + categoriaAlimenticio + ", precioAlimenticio="
				+ precioAlimenticio + "]";
	}
	
}
