package lista.estatica;

public class ProductosVestimenta {
	private int idVestimenta; 
	private String talla;
	private String color;
	private String categoria;
	private double costoVestimenta;
	public ProductosVestimenta(int idVestimenta, String talla, String color, String categoria, double costoVestimenta) {
		super();
		this.idVestimenta = idVestimenta;
		this.talla = talla;
		this.color = color;
		this.categoria = categoria;
		this.costoVestimenta = costoVestimenta;
	}
	
	public int getIdVestimenta() {
		return idVestimenta;
	}
	public void setIdVestimenta(int idVestimenta) {
		this.idVestimenta = idVestimenta;
	}
	public String getTalla() {
		return talla;
	}
	public void setTalla(String talla) {
		this.talla = talla;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public double getCostoVestimenta() {
		return costoVestimenta;
	}

	public void setCostoVestimenta(double costoVestimenta) {
		this.costoVestimenta = costoVestimenta;
	}

	@Override
	public String toString() {
		return "ProductosVestimenta [idVestimenta=" + idVestimenta + ", talla=" + talla + ", color=" + color
				+ ", categoria=" + categoria + ", costoVestimenta=" + costoVestimenta + "]";
	}
	
}
