package lista.estatica;

import java.util.Scanner;

public class ListaProductosAlimenticios {
	protected NodoProductosAlimenticios inicio, fin;// Puntero de la lista
	
	ListaProductosAlimenticios[] listaAlimentos = new ListaProductosAlimenticios [3];
	ListaProductosAlimenticios opalista = null;
	// Constructor
	int contador =0;
	private int idProductoAlimenticio;
	private String nombreAlimenticio;
	private String categoriaAlimenticio;
	private double precioAlimenticio;
	
	public ListaProductosAlimenticios(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio,
			double precioAlimenticio) {
		super();
		this.idProductoAlimenticio = idProductoAlimenticio;
		this.nombreAlimenticio = nombreAlimenticio;
		this.categoriaAlimenticio = categoriaAlimenticio;
		this.precioAlimenticio = precioAlimenticio;
	}
	public int getIdProductoAlimenticio() {
		return idProductoAlimenticio;
	}
	public void setIdProductoAlimenticio(int idProductoAlimenticio) {
		this.idProductoAlimenticio = idProductoAlimenticio;
	}
	public String getNombreAlimenticio() {
		return nombreAlimenticio;
	}
	public void setNombreAlimenticio(String nombreAlimenticio) {
		this.nombreAlimenticio = nombreAlimenticio;
	}
	public String getCategoriaAlimenticio() {
		return categoriaAlimenticio;
	}
	public void setCategoriaAlimenticio(String categoriaAlimenticio) {
		this.categoriaAlimenticio = categoriaAlimenticio;
	}
	public double getPrecioAlimenticio() {
		return precioAlimenticio;
	}
	public void setPrecioAlimenticio(double precioAlimenticio) {
		this.precioAlimenticio = precioAlimenticio;
	}
	
	public ListaProductosAlimenticios() {
		this.inicio = null;
		this.fin = null;
	}

	// Metodo para agregar un nuevo nodo Inicio Lista
	public void agregarInicioProductosAlimenticios(ProductosAlimenticios palabras) {
		inicio = new NodoProductosAlimenticios(palabras, inicio);
		// caso particular
		if (fin == null) {
			fin = inicio;
		}
	}

	// Metodo para mostrar los datos
	public void mostrarListaProductosAlimenticios() {
		NodoProductosAlimenticios recorrer = inicio;
		System.out.println();
		while (recorrer != null) {
			System.out.print("[" + recorrer.dato + "]-->");
			recorrer = recorrer.siguinte;
		}
		System.out.println("NULL");
	}
	
	public ProductosAlimenticios eliminarInicioProductosAlimenticios() {
		ProductosAlimenticios elemento =inicio.dato;
		if (inicio==fin) {
			inicio=null;
			fin=null;
			//return 0;
		}else {
			inicio=inicio.siguinte;
		}
		return elemento;
	}
	
	public ProductosAlimenticios eliminarFinalProductoAlimenticios() {
		ProductosAlimenticios elemento = fin.dato;
		if (inicio==fin) {
			inicio = null;
			fin = null;
		}else {
			NodoProductosAlimenticios temporal=inicio;
			while(temporal.siguinte != fin) {
				temporal = temporal.siguinte;
				
			}
			fin=temporal;
			fin.siguinte =null;
		}
		return elemento;
	}
	
	public boolean estaVacia() {
		if (this.inicio ==null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void agregarFinal(ProductosAlimenticios elemento) {
		//utilizar un metodo para verificar si esta vacia
		if (!estaVacia()) {
			this.fin.siguinte = new NodoProductosAlimenticios(elemento);
			this.fin = fin.siguinte;
			
		}else {
			inicio = fin = new NodoProductosAlimenticios(elemento);
			
		}
	}
public ListaProductosAlimenticios buscarPorNombre(String nombre) {
		
		if(!estaVacia()){
			for(int i = 0; i < listaAlimentos.length; i++) {
				if(listaAlimentos[i] != null) {
					if(listaAlimentos[i].getNombreAlimenticio().equals(nombre)) {
						return listaAlimentos[i];
					}
				}
		}
			return null;
		}
		return null;
	}
//(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio, double precioAlimenticio) {
	public void agregarProductosAlimenticios(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio, double precioAlimenticio) {
		
		opalista = new ListaProductosAlimenticios(idProductoAlimenticio, nombreAlimenticio, categoriaAlimenticio, precioAlimenticio);
		listaAlimentos[contador] = opalista;
		contador++;	
		
	}
	public void eliminarPorNombre(String nombre) {
		
		int indice = 0;
		
		if(buscarPorNombre(nombre) != null) {
			for(int i = 0; i < listaAlimentos.length; i++) {
				 if(listaAlimentos[i] != null) {
					 if(listaAlimentos[i].getNombreAlimenticio().equals(nombre)) {
							indice = i;
					}
				 }
				 
			 }
			 System.arraycopy(listaAlimentos,indice+1,listaAlimentos,indice,listaAlimentos.length-1-indice);
			 System.out.println("Elemento eliminado");
			
		}else {
			System.out.println("Elemento no existe");
		}
	}
	public void mostrarLista() {
		for(int i = 0;  i < listaAlimentos.length; i++ ){
			if(listaAlimentos[i] != null){
				System.out.println( "Nombre: " +listaAlimentos[i].getNombreAlimenticio()+ " ID: " +listaAlimentos[i].getIdProductoAlimenticio()+ " Precio :  \n"+listaAlimentos[i].getPrecioAlimenticio());
			}
			
		}
		
	}
	
	
	//(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio, double precioAlimenticio) {

	public void actualizarElemento(int n) {
		Scanner actu = new Scanner(System.in);
		System.out.println("Digite el nombre del producto: ");
		String nombreProducto = actu.next();
		System.out.println("Digite el costo del producto: ");
		double costoProducto = actu.nextDouble();
		System.out.println("Digite la categoria: ");
		String categoriaProducto = actu.next();
		System.out.println("Digite el ID del producto: ");
		int idProducto = actu.nextInt();
		
		listaAlimentos[n-1].setIdProductoAlimenticio(idProducto);
		listaAlimentos[n-1].setNombreAlimenticio(nombreProducto);
		listaAlimentos[n-1].setCategoriaAlimenticio(categoriaProducto);
		listaAlimentos[n-1].setPrecioAlimenticio(costoProducto);
	}
}

