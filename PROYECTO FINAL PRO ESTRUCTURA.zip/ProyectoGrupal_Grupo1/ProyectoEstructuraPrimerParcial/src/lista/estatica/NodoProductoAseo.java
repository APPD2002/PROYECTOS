package lista.estatica;


public class NodoProductoAseo {
	public ProductoAseo dato;// Donde almaceno la estructura de datos
	public NodoProductoAseo siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoProductoAseo(ProductoAseo ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoProductoAseo(ProductoAseo palabras, NodoProductoAseo nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}
}
