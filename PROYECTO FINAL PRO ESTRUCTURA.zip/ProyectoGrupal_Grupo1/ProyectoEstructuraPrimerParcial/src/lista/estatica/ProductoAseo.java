package lista.estatica;

public class ProductoAseo {
	private String nombreProducto;
	private double costoProducto;
	private String categoria;
	private int idProductoAseo;
	private String descripcionAseo;
	

	public ProductoAseo(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,
			String descripcionAseo) {
		super();
		this.nombreProducto = nombreProducto;
		this.costoProducto = costoProducto;
		this.categoria = categoria;
		this.idProductoAseo = idProductoAseo;
		this.descripcionAseo = descripcionAseo;
	}
	
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public double getCostoProducto() {
		return costoProducto;
	}
	public void setCostoProducto(double costoProducto) {
		this.costoProducto = costoProducto;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public int getIdProductoAseo() {
		return idProductoAseo;
	}
	public void setIdProductoAseo(int idProductoAseo) {
		this.idProductoAseo = idProductoAseo;
	}
	public String getDescripcionAseo() {
		return descripcionAseo;
	}
	public void setDescripcionAseo(String descripcionAseo) {
		this.descripcionAseo = descripcionAseo;
	}

	@Override
	public String toString() {
		return "ProductoAseo [nombreProducto=" + nombreProducto +  ", categoria="
				+ categoria + ", idProductoAseo=" + idProductoAseo + ", descripcionAseo=" + descripcionAseo + "]";
	}
	
}
