package vista;

import java.util.Scanner;

import javax.swing.JOptionPane;

import lista.dinamica.Cliente;
import lista.dinamica.ListaCliente;
import lista.dinamica.ListaProveedor;
import lista.dinamica.Proveedor;
import lista.estatica.ListaProductoAseo;
import lista.estatica.ListaProductosAlimenticios;
import lista.estatica.ListaProductosVestimenta;
import pilas.PilaCocina;
import pilas.PilaLimpieza;
import pilas.PilaRopa;
import pilas.ProductosCocina;
import pilas.ProductosLimpieza;
import pilas.ProductosRopa;

public class MenuPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListaCliente ocLista  = new ListaCliente();
		ListaProveedor opLista = new ListaProveedor();
		int menu=0;
		System.out.println("\t\tPROYECTO PRIMER PARCIAL DE ESTRUCTURA");
		System.out.println("1.- Lista Dinamica");
		System.out.println("2.- Lista Estatica ");
		System.out.println("3.- Pila");
		System.out.print("\nSu opcion es: ");
		Scanner oc = new Scanner (System.in);
		int menuF = oc.nextInt();
		if(menuF ==1) {
			
		
		do {
			try {
		System.out.println("\n1.- Ingresar al Sistema los Clientes");
		System.out.println("2.- Ingresar al Sistema los Proveedores");
		System.out.println("3.- Salir");
		System.out.print("Su opcion es: ");
		Scanner sc = new Scanner (System.in);
		menu = sc.nextInt();
		if(menu ==1) {
		System.out.print("Digite el Cedula: ");
		int cedula = sc.nextInt();
		System.out.print("Digite el Nombre: ");
		String nombreCliente = sc.next();
		System.out.print("Digite el Apellido: ");
		String apellidoCliente = sc.next();
		System.out.print("Digite el Genero: ");
		String generoCliente = sc.next();
		System.out.print("Digite el Celular: ");
		int celularCliente = sc.nextInt();
		System.out.println("\n\t\tOPCIONES A REALIZAR");
		System.out.println("\n1.- Ingresar Cliente al Inicio de la Lista");
		System.out.println("2.- Ingresar Cliente al Final");
		System.out.println("3.- Eliminar Final de Lista ");
		System.out.println("4.- Mostrar Datos");
		//(int cedula, String nombres, String apellidos, String genero, int celular) {
		Cliente cliente = new Cliente(celularCliente, nombreCliente, apellidoCliente, generoCliente, celularCliente);
		System.out.print("Su opcion es: ");
		int menuCliente = sc.nextInt();
		switch (menuCliente) {
		case 1:
			try {
				System.out.println("Colocaldo al cliente al INICIO");
				ocLista.agregarInicioCliente(cliente);
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 2:
			try {
				System.out.println("Colocaldo al cliente al final");
				ocLista.agregarFinal(cliente);
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 3:
			try {
				System.out.println("Elimando Final de lista del Cliente Residencia");
				ocLista.eliminarFinalPersona();			

			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 4:
			ocLista.mostrarListaCliente();
			break;
			default:
				System.out.println("ERROR");
		}
	}
		else if(menu ==3) {
			Scanner prove = new Scanner (System.in);
			System.out.print("Digite el RUC: ");
			int ruc = prove.nextInt();
			System.out.print("Digite el Nombre: ");
			String nombreProveedor = prove.next();
			System.out.print("Digite el Apellido: ");
			String apellidoProveedor = prove.next();
			System.out.print("Digite el correo: ");
			String correoProveedor = prove.next();
			System.out.print("Digite el telefono: ");
			int telefonoProveedor =  prove.nextInt();
			System.out.println("\n\t\tOPCIONES A REALIZAR");
			System.out.println("\n1.- Ingresar Proveedor al Inicio de la Lista");
			System.out.println("2.- Ingresar Cliente al Final");
			System.out.println("3.- Eliminar Final de Lista ");
			System.out.println("4.- Mostrar Datos");
			System.out.println("5.- Buscar Cliente");
			//(int rUC, String nombres, String apellidos, String correo, int telefono) {
			Proveedor proveedor = new Proveedor(ruc, nombreProveedor, apellidoProveedor, correoProveedor, telefonoProveedor);
			int menuProveedor = sc.nextInt();
			switch (menuProveedor) {
			case 1:
				try {
					System.out.println("Colocaldo al Proveedor al INICIO");
					opLista.agregarInicioProveedor(proveedor);
				
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("Colocando al Proveedor al final");
					opLista.agregarFinal(proveedor);
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Elimando Final de lista del Proveedor Residencia");
					opLista.eliminarFinalPersona();

				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 4:
				opLista.mostrarListaProveedor();
				break;
			default: 
				System.out.println("ERROR!!!");
			}
		}
			
	} catch (Exception e) {

	}

} while (menu != 5);
		}
		else if(menuF ==2) {
			ListaProductoAseo opaLista  = new ListaProductoAseo();
			ListaProductosAlimenticios opaliLista = new ListaProductosAlimenticios();
			ListaProductosVestimenta opvLista = new ListaProductosVestimenta();
			System.out.println("Software que permite ingresar productos al sistema de forma DINAMICA PARA 5");
			Scanner sc = new Scanner (System.in);
			int e1;
			int menu2 = 0;
			do {
				try {
			System.out.println("1.- Ingresar Productos de Aseo ");
			System.out.println("2.- Ingresar Productos Alimenticios");
			System.out.println("3.- Ingresar Productos de Vestimenta");
			System.out.println("3.- Salir");
			System.out.print("Su opcion es: ");
			menu2 = sc.nextInt();
			if(menu2 ==1) {
			System.out.print("Digite el nombre: ");
			String nombreAseo  = sc.next();
			System.out.print("Digite la categoria: ");
			String categoriaAseo = sc.next();
			System.out.print("Digite el ID del producto aseo: ");
			int idProductoAseo = sc.nextInt();
			System.out.print("Digite la descripcion: ");
			String  descripcion = sc.next();
			System.out.println("\n\t\tOPCIONES A REALIZAR");
			System.out.println("\n1.- Ingresar Producto");
			System.out.println("2.- Actualizar Producto");
			System.out.println("3.- Eliminar Producto ");
			System.out.println("4.- Mostrar Datos");
			//(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,tring descripcionAseo) {
			System.out.print("Su opcion es: ");
			int menuCliente = sc.nextInt();
			switch (menuCliente) {
			case 1:
				try {
					System.out.println("Ingresar producto");
					opaLista.agregarProductoAseo(nombreAseo, categoriaAseo, idProductoAseo, descripcion);
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("Digite el ID del producto que quiere actualizar");
					e1 = sc.nextInt();
					opaLista.actualizarElemento(e1);
			
				
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Digite el nombre del producto que quiere borrar");
					String nombreBorrar = sc.next();
					opaLista.eliminarPorNombre(nombreBorrar);
		
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 4:
				opaLista.mostrarLista();
				break;
				default: 
					System.out.println("ERROR!!!");
					
			/*else if(menu ==2) {
				
			}*/
			}
			
			} else if(menu==2) {
				//(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio, double precioAlimenticio) {
				System.out.print("Digite el ID del producto Alimenticio ");
				int idProAlimenticio  = sc.nextInt();
				System.out.print("Digite el nombre del producto ");
				String nombreAlimento = sc.next();
				System.out.print("Digite la categoria: ");
				String categoriaAlimento = sc.next();
				System.out.print("Digite el precio del alimento ");
				double precioAlimento = sc.nextDouble();
				System.out.println("\n\t\tOPCIONES A REALIZAR");
				System.out.println("\n1.- Ingresar Producto");
				System.out.println("2.- Actualizar Producto");
				System.out.println("3.- Eliminar Producto ");
				System.out.println("4.- Mostrar Datos");
				//(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,tring descripcionAseo) {
				
				System.out.print("Su opcion es: ");
				int menuCliente = sc.nextInt();
				switch (menuCliente) {
				case 1:
					try {
						System.out.println("Ingresar producto");
						opaliLista.agregarProductosAlimenticios(idProAlimenticio, nombreAlimento, categoriaAlimento, precioAlimento);
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 2:
					try {
						System.out.println("Digite el ID del producto que quiere actualizar");
						e1 = sc.nextInt();
						opaliLista.actualizarElemento(e1);
				
					
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 3:
					try {
						System.out.println("Digite el nombre del producto que quiere borrar");
						String nombreBorrar = sc.next();
						opaliLista.eliminarPorNombre(nombreBorrar);
			
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 4:
					opaLista.mostrarLista();
					break;
					default: 
						System.out.println("ERROR!!!");
				}
			}else if(menu==3) {
				// nombreVestimenta,  idVestimenta,  talla, String color, String categoria, double costoVestimenta) {
				System.out.print("Digite el nombre de la Vestimenta: ");
				String nombreVestimenta  = sc.next();
				System.out.print("Digite el ID de la Vestimenta ");
				int idVestimenta = sc.nextInt();
				System.out.print("Digite la Talla: ");
				String tallaVestimenta = sc.next();
				System.out.print("Digite el color de la Vestimenta: ");
				String colorVestimenta = sc.next();
				System.out.print("Digite la Categoria: ");
				String categoriaVestimenta = sc.next();
				System.out.print("Digite el costo de la Vestimenta: ");
				double  costoVestimenta = sc.nextDouble();
				System.out.println("\n\t\tOPCIONES A REALIZAR");
				System.out.println("\n1.- Ingresar Producto");
				System.out.println("2.- Actualizar Producto");
				System.out.println("3.- Eliminar Producto ");
				System.out.println("4.- Mostrar Datos");
				
				System.out.print("Su opcion es: ");
				int menuCliente = sc.nextInt();
				switch (menuCliente) {
				case 1:
					try {
						System.out.println("Ingresar producto");
						opvLista.agregarProductoVestimenta(nombreVestimenta, idVestimenta, tallaVestimenta, colorVestimenta, categoriaVestimenta, costoVestimenta);
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 2:
					try {
						System.out.println("Digite el ID del producto que quiere actualizar");
						e1 = sc.nextInt();
						opvLista.actualizarElemento(e1);
						
					
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 3:
					try {
						System.out.println("Digite el nombre del producto que quiere borrar");
						String nombreBorrar = sc.next();
						opvLista.eliminarPorNombre(nombreBorrar);
			
					} catch (NumberFormatException n) {
						JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
					}
					break;
				case 4:
					opaLista.mostrarLista();
					break;
					default: 
						System.out.println("ERROR!!!");
				}
			}
				}catch (Exception e) {

			}

		} while (menu != 3);
		}
		else if(menuF ==3) {
			Scanner sc = new Scanner(System.in);
			//Crear objetos de las clases
			        ProductosCocina cocina;
			        ProductosLimpieza limpieza;
			        ProductosRopa ropa;
			//Variables para ingresar datos en pilas
			        int codigo;
			        String nombre;
			        double precio;
			        boolean descuento;
			        int talla;
			        double precioFinal;
			        int opcDescuento;
			        /*
			        ********************************************
			                   MENÚ PRODUCTO PILA
			        ********************************************
			        */
			       
			        System.out.println("**********************************************"); 
			       System.out.println("Bienvenido a Menú Pila de Productos TIPO PILA");
			        System.out.println("**********************************************");
			        System.out.println("");
			        int opcMenu, menuPilaCocina, menuPilaLimpieza, menuPilaRopa; 
			        int cantCocina, cantLimpieza, cantRopa ;
			        try{
			        do{
			        System.out.println("Elija uno de los siguientes Submenús:\n"
			                + "   1.- Productos de Cocina\n"
			                + "   2.- Productos de Limpieza\n"
			                + "   3.- Productos de Ropa");
			        opcMenu = sc.nextInt();
			        switch (opcMenu){
			            case 1:
			                System.out.println("--> BIENVENIDO PILA PRODUCTOS DE COCINA <--");
			                System.out.print("Seleccione cuantos elementos de cocina desea tener en su pila:");
			                cantCocina=sc.nextInt();
			                PilaCocina oPilaCoc = new PilaCocina(cantCocina);
			                do{
			                System.out.println("\nIndique qué Opción desea elegir: \n"
			                        + "   1.- Ingresar un producto a la Pila\n"
			                        + "   2.- Sacar un elemento de la Pila\n"
			                        + "   3.- Revisar último elemento colocado\n"
			                        + "   4.- Tamaño de la pila\n"
			                        + "   5.- Salir");
			                menuPilaCocina=sc.nextInt();
			                switch(menuPilaCocina){
			                    case 1:
			                        System.out.println(" INGRESAR UN PRODUCTO DE COCINA A LA PILA ");
			                        System.out.println("Ingrese los siguientes datos: ");
			                        System.out.print("Código: ");
			                        codigo = sc.nextInt();
			                        sc.nextLine();
			                        System.out.print("Nombre: ");
			                        nombre = sc.nextLine();
			                        System.out.print("Precio: ");
			                        precio = sc.nextDouble();
			                        System.out.print("Presione 1 si existe descuento, caso contrario presione otra tecla: ");
			                        sc.nextLine();
			                        opcDescuento = sc.nextInt();
			                        if(opcDescuento == 1){
			                            descuento=true;
			                        }else{
			                            descuento=false;
			                        }
			                        cocina = new ProductosCocina(codigo, nombre, precio, descuento);
			                        cocina.calcularPrecio();
			                        if (!oPilaCoc.estaLlena()) {
			                            oPilaCoc.push(cocina);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
			                                    JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                    
			                    case 2:
			                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
			                        if (!oPilaCoc.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El producto sacado es:\n"
			                                    +oPilaCoc.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                        
			                    case 3:
			                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO COLOCADO EN LA PILA:");
			                        if (!oPilaCoc.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El rpoducto que esta en la CIMA es:"
			                                    + oPilaCoc.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

			                        }
			                        break;
			                        
			                    case 4: 
			                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
			                        System.out.println("El tamaño de la Pila es: "+oPilaCoc.tamanioPila());
			                        break;
			                    
			                    default:
			                    System.out.println("Indique la opción correcta");    
			                }
			                }while(menuPilaCocina != 5);
			                
			                break;
			                
			            case 2:
			                System.out.println("--> BIENVENIDO PILA PRODUCTOS DE LIMPIEZA <--");
			                System.out.print("Seleccione cuantos elementos de limpieza desea tener en su pila:");
			                cantLimpieza=sc.nextInt();
			                PilaLimpieza oPilaLim = new PilaLimpieza(cantLimpieza);
			                do{
			                System.out.println("\nIndique qué Opción desea elegir: \n"
			                        + "   1.- Ingresar un producto a la Pila\n"
			                        + "   2.- Sacar un elemento de la Pila\n"
			                        + "   3.- Revisar último elemento colocado\n"
			                        + "   4.- Tamaño de la pila\n"
			                        + "   5.- Salir");
			                menuPilaLimpieza=sc.nextInt();
			                switch(menuPilaLimpieza){
			                    case 1:
			                        System.out.println(" INGRESAR UN PRODUCTO DE LIMPIEZA A LA PILA ");
			                        System.out.println("Ingrese los siguientes datos: ");
			                        System.out.print("Código: ");
			                        codigo = sc.nextInt();
			                        sc.nextLine();
			                        System.out.print("Nombre: ");
			                        nombre = sc.nextLine();
			                        System.out.print("Precio: ");
			                        precio = sc.nextDouble();
			                        System.out.print("Presione 1 si existe descuento, caso contrario presione otra tecla: ");
			                        sc.nextLine();
			                        opcDescuento = sc.nextInt();
			                        if(opcDescuento == 1){
			                            descuento=true;
			                        }else{
			                            descuento=false;
			                        }
			                        //CREACIÓN DE OBJETO
			                        limpieza = new ProductosLimpieza(codigo, nombre, precio, descuento);
			                        limpieza.calcularPrecio();
			                        if (!oPilaLim.estaLlena()) {
			                            oPilaLim.push(limpieza);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
			                                    JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                    
			                    case 2:
			                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
			                        if (!oPilaLim.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El producto sacado es:\n"
			                                    +oPilaLim.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                        
			                    case 3:
			                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO COLOCADO EN LA PILA:");
			                        if (!oPilaLim.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El producto que esta en la CIMA es:"
			                                    + oPilaLim.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

			                        }
			                        break;
			                        
			                    case 4: 
			                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
			                        System.out.println("El tamaño de la Pila es: "+oPilaLim.tamanioPila());
			                        break;
			                    
			                    default:
			                    System.out.println("Indique la opción correcta");    
			                }
			                }while(menuPilaLimpieza != 5);
			                
			                break;
			                
			            case 3:
			                System.out.println("--> BIENVENIDO PILA ROPA <--");
			                System.out.print("Seleccione cuantos elementos de ropa desea tener en su pila:");
			                cantRopa=sc.nextInt();
			                PilaRopa oPilaRopa = new PilaRopa(cantRopa);
			                do{
			                System.out.println("\nIndique qué Opción desea elegir: \n"
			                        + "   1.- Ingresar un producto a la Pila\n"
			                        + "   2.- Sacar un elemento de la Pila\n"
			                        + "   3.- Revisar último elemento colocado\n"
			                        + "   4.- Tamaño de la pila\n"
			                        + "   5.- Salir");
			                menuPilaRopa=sc.nextInt();
			                switch(menuPilaRopa){
			                    case 1:
			                        System.out.println(" INGRESAR UN PRODUCTO DE ROPA ");
			                        System.out.println("Ingrese los siguientes datos: ");
			                        System.out.print("Código: ");
			                        codigo = sc.nextInt();
			                        sc.nextLine();
			                        System.out.print("Nombre: ");
			                        nombre = sc.nextLine();
			                        System.out.println("Talla(entero): ");
			                        talla = sc.nextInt();
			                        System.out.print("Precio: ");
			                        precio = sc.nextDouble();
			                        System.out.print("Presione 1 si existe descuento, caso contrario presione 0: ");
			                        sc.nextLine();
			                        opcDescuento = sc.nextInt();
			                        if(opcDescuento == 1){
			                            descuento=true;
			                        }else{
			                            descuento=false;
			                        }
			                        //CREACIÓN DE OBJETO
			                        ropa = new ProductosRopa(codigo, nombre, talla, precio, descuento);
			                        ropa.calcularPrecio();
			                        if (!oPilaRopa.estaLlena()) {
			                            oPilaRopa.push(ropa);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
			                                    JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                    
			                    case 2:
			                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
			                        if (!oPilaRopa.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El producto (ropa) sacado es:\n"
			                                    +oPilaRopa.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
			                        }
			                        break;
			                        
			                    case 3:
			                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO (ROPA) COLOCADO EN LA PILA:");
			                        if (!oPilaRopa.estaVacia()) {
			                            JOptionPane.showMessageDialog(null, "El producto que esta en la CIMA es:"
			                                    + oPilaRopa.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
			                        } else {
			                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

			                        }
			                        break;
			                        
			                    case 4: 
			                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
			                        System.out.println("El tamaño de la Pila es: "+oPilaRopa.tamanioPila());
			                        break;
			                    
			                    default:
			                    System.out.println("Indique la opción correcta");    
			                }
			                }while(menuPilaRopa != 5);
			                
			                break;
			        }
			        
			        }while(opcMenu!=4);
			        } catch (NumberFormatException n) {
			            JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			        }
		}
		else {
			System.out.println("Vuelva a intentar");
		}
	}

}
