
package listasClienteProveedor;
public class NodoProveedor {
    public Proveedor dato;// Donde almaceno la estructura de datos
	public NodoProveedor siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoProveedor(Proveedor ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoProveedor(Proveedor palabras, NodoProveedor nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}
}
