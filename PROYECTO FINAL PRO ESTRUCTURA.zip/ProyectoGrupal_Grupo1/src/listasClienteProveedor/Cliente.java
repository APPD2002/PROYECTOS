
package listasClienteProveedor;

public class Cliente {
    private String cedula;
    private String nombres;
    private String apellidos;
    private String correo;
    private String celular;

    public Cliente(String cedula, String nombres, String apellidos, String correo, String celular) {
            super();
            this.cedula = cedula;
            this.nombres = nombres;
            this.apellidos = apellidos;
            this.correo = correo;
            this.celular = celular;
    }
    public Cliente(){
        
        this.cedula = null;
            this.nombres = null;
            this.apellidos = null;
            this.correo = null;
            this.celular = null;
    }
    

    public String getNombres() {
            return nombres;
    }

    public void setNombres(String nombres) {
            this.nombres = nombres;
    }

    public String getApellidos() {
            return apellidos;
    }

    public void setApellidos(String apellidos) {
            this.apellidos = apellidos;
    }

    public String getGenero() {
            return correo;
    }

    public void setGenero(String genero) {
            this.correo = genero;
    }

    public String getCelular() {
            return celular;
    }

    public void setCelular(String celular) {
            this.celular = celular;
    }

    @Override
    public String toString() {
            return "Cedula:  " + cedula + ", Nombre: " + nombres + " Apellido: " + apellidos + ", Correo: " + correo + ", Celular: " + celular + "]";
    }
}
