
package listasEstatica;

public class AseoEstatico {
    private String nombre;
    private int codigo;
    private double precio;
    
    
    //CONSTRUCTOR
    public AseoEstatico(String nombre, int codigo, double precio) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
    }  
    //tO sTRING
    @Override
    public String toString() {
        return "AseoEstatico[" + "Nombre= " + nombre + ", Código= " + codigo + ", Precio= " + precio + ']';
    }  
}
