
package listasEstatica;

import javax.swing.JOptionPane;


public class ListaVestEstatico {
   public NodoVestEstatico inicio, fin;// Puntero de la lista
  private int numLimite=0;
  private static int contador=1;

        //Cambiar valor de límite
  public void setNumLimite(int limite){
      this.numLimite=limite;
  }
	// Constructor
    public ListaVestEstatico() {
            this.inicio = null;
            this.fin = null;
    }
        // Metodo para agregar un nuevo nodo Inicio Lista
    public void agregarInicio(VestimentaEstatico palabras) {
        if(contador<=numLimite){
            inicio = new NodoVestEstatico(palabras, inicio);
            // caso particular
            if (fin == null) {
                    fin = inicio;
            }
            this.contador++;
        }else{
            JOptionPane.showMessageDialog(null, "La lista se encuentra llena");
        }
    }
         // Metodo para mostrar los datos
    public String mostrarLista() {
            NodoVestEstatico recorrer = inicio;
            String mostrar="";

            System.out.println();
            while (recorrer != null) {
                    mostrar = mostrar+"[" + recorrer.dato + "]-->\n";

                    recorrer = recorrer.siguiente;
            }
            mostrar=mostrar+"null";
            return mostrar;
    }

    public VestimentaEstatico eliminarInicio() {
            VestimentaEstatico elemento =inicio.dato;
            if (inicio==fin) {
                    inicio=null;
                    fin=null;
                    //return 0;
            }else {
                    inicio=inicio.siguiente;
            }
            this.contador--;
            return elemento;

    }
    public VestimentaEstatico eliminarFinal() {
            VestimentaEstatico elemento = fin.dato;
            if (inicio==fin) {
                    inicio = null;
                    fin = null;
            }else {
                    NodoVestEstatico temporal=inicio;
                    while(temporal.siguiente != fin) {
                            temporal = temporal.siguiente;
                    }
                    fin=temporal;
                    fin.siguiente =null;
            }
            this.contador--;
            return elemento;
    }
    public boolean estaVacia() {
            if (this.inicio ==null) {
                    return true;
            }
            else {
                    return false;
            }
    }
    public void agregarFinal(VestimentaEstatico elemento) {
            //utilizar un metodo para verificar si esta vacia
        if(contador<=numLimite){
            if (!estaVacia()) {
                    this.fin.siguiente = new NodoVestEstatico(elemento);
                    this.fin = fin.siguiente;

            }else {
                    inicio = fin = new NodoVestEstatico(elemento);
            }
            this.contador++;
        }else{
            JOptionPane.showMessageDialog(null, "La lista se encuentra llena");
        }
    }  
}
