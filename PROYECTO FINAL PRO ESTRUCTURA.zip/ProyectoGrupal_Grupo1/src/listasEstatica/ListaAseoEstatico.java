
package listasEstatica;
import javax.swing.JOptionPane;

public class ListaAseoEstatico {
  public NodoAseoEstatico inicio, fin;// Puntero de la lista
  private int numLimite=0;
  private static int contador=1;

        //Cambiar valor de límite
  public void setNumLimite(int limite){
      this.numLimite=limite;
  }
	// Constructor
    public ListaAseoEstatico() {
            this.inicio = null;
            this.fin = null;
    }
        // Metodo para agregar un nuevo nodo Inicio Lista
    public void agregarInicio(AseoEstatico palabras) {
        if(contador<=numLimite){
            inicio = new NodoAseoEstatico(palabras, inicio);
            // caso particular
            if (fin == null) {
                    fin = inicio;
            }
            this.contador++;
        }else{
            JOptionPane.showMessageDialog(null, "La lista se encuentra llena");
        }
    }
         // Metodo para mostrar los datos
    public String mostrarLista() {
            NodoAseoEstatico recorrer = inicio;
            String mostrar="";

            System.out.println();
            while (recorrer != null) {
                    mostrar = mostrar+"[" + recorrer.dato + "]-->\n";

                    recorrer = recorrer.siguinte;
            }
            mostrar=mostrar+"null";
            return mostrar;
    }

    public AseoEstatico eliminarInicio() {
            AseoEstatico elemento =inicio.dato;
            if (inicio==fin) {
                    inicio=null;
                    fin=null;
                    //return 0;
            }else {
                    inicio=inicio.siguinte;
            }
            this.contador--;
            return elemento;

    }
    public AseoEstatico eliminarFinal() {
            AseoEstatico elemento = fin.dato;
            if (inicio==fin) {
                    inicio = null;
                    fin = null;
            }else {
                    NodoAseoEstatico temporal=inicio;
                    while(temporal.siguinte != fin) {
                            temporal = temporal.siguinte;
                    }
                    fin=temporal;
                    fin.siguinte =null;
            }
            this.contador--;
            return elemento;
    }
    public boolean estaVacia() {
            if (this.inicio ==null) {
                    return true;
            }
            else {
                    return false;
            }
    }
    public void agregarFinal(AseoEstatico elemento) {
            //utilizar un metodo para verificar si esta vacia
        if(contador<=numLimite){
            if (!estaVacia()) {
                    this.fin.siguinte = new NodoAseoEstatico(elemento);
                    this.fin = fin.siguinte;

            }else {
                    inicio = fin = new NodoAseoEstatico(elemento);
            }
            this.contador++;
        }else{
            JOptionPane.showMessageDialog(null, "La lista se encuentra llena");
        }
    }  
}
