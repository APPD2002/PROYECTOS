/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listasEstatica;

public class AlimentosEstatico {
        private String nombre;
        private int codigo;
        private double precio;
    
    //CONSTRUCTOR
    public AlimentosEstatico(String nombre, int codigo, double precio) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
    }  
    //tO sTRING
    @Override
    public String toString() {
        return "  AlimentosEstatico {"  +  "Nombre= " + nombre + ", Código= " + codigo + ", Precio= " + precio + '}';
    }
}
