/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listasEstatica;


public class NodoAseoEstatico {
  public AseoEstatico dato;// Donde almaceno la estructura de datos
	public NodoAseoEstatico siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoAseoEstatico(AseoEstatico ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoAseoEstatico(AseoEstatico palabras, NodoAseoEstatico nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}    
}
