
package listasEstatica;

public class NodoVestEstatico {
    
public VestimentaEstatico dato;// Donde almaceno la estructura de datos
	public NodoVestEstatico siguiente;// Puntero

	// Constructor inserta al final de la lista
	public NodoVestEstatico(VestimentaEstatico ndato) {
		this.dato = ndato;
		this.siguiente = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoVestEstatico(VestimentaEstatico palabras, NodoVestEstatico nnodo) {
		this.dato = palabras;
		this.siguiente = nnodo;
	}    
}
