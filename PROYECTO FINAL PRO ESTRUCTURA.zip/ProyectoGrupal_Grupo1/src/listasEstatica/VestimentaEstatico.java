
package listasEstatica;


public class VestimentaEstatico {
    private String nombre;
    private int codigo;
    private double precio;
    private String talla;
    
    //CONSTRUCTOR
    public VestimentaEstatico(String nombre, int codigo, double precio, String talla) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
        this.talla = talla;
    }  
    //tO sTRING
    @Override
    public String toString() {
        return "VestimentaEstatico[" + "Nombre= " + nombre + ", Código= " + codigo + ", Precio= " + precio +", Talla= " + talla + ']';
    }  
}

