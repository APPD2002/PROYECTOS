
package listasEstatica;

public class NodoAlimentosEstatico {
        public AlimentosEstatico dato;// Donde almaceno la estructura de datos
	public NodoAlimentosEstatico siguiente;// Puntero

	// Constructor inserta al final de la lista
	public NodoAlimentosEstatico(AlimentosEstatico ndato) {
		this.dato = ndato;
		this.siguiente = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoAlimentosEstatico(AlimentosEstatico palabras, NodoAlimentosEstatico nnodo) {
		this.dato = palabras;
		this.siguiente = nnodo;
	}    
}
