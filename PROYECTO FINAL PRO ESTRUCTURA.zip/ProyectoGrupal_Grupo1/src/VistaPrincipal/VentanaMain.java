
package VistaPrincipal;


public class VentanaMain {
    public static void main(String[] args) {
           
            FrmAcercaDe acercaDe = new FrmAcercaDe();
            acercaDe.setVisible(true);
    }
    
}
