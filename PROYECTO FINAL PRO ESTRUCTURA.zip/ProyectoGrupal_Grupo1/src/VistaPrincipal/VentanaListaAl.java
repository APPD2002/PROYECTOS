package VistaPrincipal;

import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import listasEstatica.*;

public class VentanaListaAl extends javax.swing.JFrame {
     
	 String nombreProducto;
	 double costoProducto;
         int idProductoAseo;
         ListaAlimentosEstatico oAlimLista = new ListaAlimentosEstatico();
         AlimentosEstatico alimentos;
 
    public VentanaListaAl() {
        initComponents();
        txtNombreLista.setEnabled(false);
        txtCodigoLista.setEnabled(false);
        txtPrecioLista.setEnabled(false);
        btnAgregarFinal.setEnabled(false);
        btnAgregarInicio.setEnabled(false);
        btnEliminarFinal.setEnabled(false);
        btnEliminarInicio.setEnabled(false);
        this.setLocationRelativeTo(null);
        this.setResizable(false); //No poder maximizar 
        setTitle("Ventana lista productos");
    }    
         
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jToggleButton1 = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        lblNombreL = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        lblCodigoL = new javax.swing.JLabel();
        lblPrecioL = new javax.swing.JLabel();
        txtNombreLista = new javax.swing.JTextField();
        txtCodigoLista = new javax.swing.JTextField();
        txtPrecioLista = new javax.swing.JTextField();
        btnAgregarInicio = new javax.swing.JButton();
        btnAgregarFinal = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtMostrarLista = new javax.swing.JTextArea();
        btnEliminarInicio = new javax.swing.JButton();
        btnEliminarFinal = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtLimProductos = new javax.swing.JTextField();
        btnGenerarLimite = new javax.swing.JButton();

        jRadioButton1.setText("jRadioButton1");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lblNombreL.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        lblNombreL.setText("Nombre:");

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));

        titulo.setBackground(new java.awt.Color(204, 204, 255));
        titulo.setFont(new java.awt.Font("Stencil", 1, 24)); // NOI18N
        titulo.setText("productos de alimentos ");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/atras 20.png"))); // NOI18N
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setDefaultCapable(false);
        jButton2.setFocusPainted(false);
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/comida (2).gif"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/comida.gif"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jButton3.setDefaultCapable(false);
        jButton3.setFocusable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jButton3)
                .addGap(2, 2, 2)
                .addComponent(titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(titulo)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(21, 21, 21)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblCodigoL.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        lblCodigoL.setText("Código");

        lblPrecioL.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        lblPrecioL.setText("Precio:");

        txtNombreLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreListaActionPerformed(evt);
            }
        });

        txtCodigoLista.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodigoListaKeyTyped(evt);
            }
        });

        txtPrecioLista.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioListaKeyTyped(evt);
            }
        });

        btnAgregarInicio.setFont(new java.awt.Font("Stencil", 0, 12)); // NOI18N
        btnAgregarInicio.setText("Agregar inicio");
        btnAgregarInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        btnAgregarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarInicioActionPerformed(evt);
            }
        });

        btnAgregarFinal.setFont(new java.awt.Font("Stencil", 0, 12)); // NOI18N
        btnAgregarFinal.setText("Agregar final");
        btnAgregarFinal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        btnAgregarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarFinalActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Elementos Lista", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Black", 0, 12))); // NOI18N

        txtMostrarLista.setEditable(false);
        txtMostrarLista.setColumns(20);
        txtMostrarLista.setRows(5);
        jScrollPane2.setViewportView(txtMostrarLista);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                .addContainerGap())
        );

        btnEliminarInicio.setFont(new java.awt.Font("Stencil", 0, 12)); // NOI18N
        btnEliminarInicio.setText("Eliminar Inicio");
        btnEliminarInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        btnEliminarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarInicioActionPerformed(evt);
            }
        });

        btnEliminarFinal.setFont(new java.awt.Font("Stencil", 0, 12)); // NOI18N
        btnEliminarFinal.setText("Eliminar Final");
        btnEliminarFinal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        btnEliminarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarFinalActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Colocar límite de Productos:");

        txtLimProductos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtLimProductos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLimProductosKeyTyped(evt);
            }
        });

        btnGenerarLimite.setFont(new java.awt.Font("Stencil", 0, 12)); // NOI18N
        btnGenerarLimite.setText("GENERAR");
        btnGenerarLimite.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));
        btnGenerarLimite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarLimiteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(btnAgregarInicio)
                        .addGap(18, 18, 18)
                        .addComponent(btnAgregarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(btnEliminarInicio)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(lblNombreL, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreLista, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblCodigoL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoLista, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPrecioL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecioLista, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtLimProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnGenerarLimite, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnGenerarLimite, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtLimProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreL)
                    .addComponent(txtNombreLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCodigoL)
                    .addComponent(txtCodigoLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrecioL)
                    .addComponent(txtPrecioLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel4.getAccessibleContext().setAccessibleName("Elementos lista");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarInicioActionPerformed
      if(txtCodigoLista.getText().isEmpty()) {
           JOptionPane.showMessageDialog(null, "Por favor, colocar codigo");
      }
      else if (txtNombreLista.getText().isEmpty()){
           JOptionPane.showMessageDialog(null, "Por favor, colocar nombre");
      }
      else if(txtPrecioLista.getText().isEmpty()){
           JOptionPane.showMessageDialog(null, "Por favor, colocar precio");
      }else{
          
      
        nombreProducto = txtNombreLista.getText();
        idProductoAseo = Integer.parseInt(txtCodigoLista.getText());
        costoProducto = Double.parseDouble(txtPrecioLista.getText());
        
        alimentos = new AlimentosEstatico(nombreProducto,idProductoAseo,costoProducto);
        oAlimLista.agregarInicio(alimentos);
           try{
        JOptionPane.showMessageDialog(null, "Colocando producto al Inicio");
        
        txtMostrarLista.setText(oAlimLista.mostrarLista());
        
        vaciarDatosLista();
        }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error "+e.getMessage());
       }
           }
    }//GEN-LAST:event_btnAgregarInicioActionPerformed
    
   
    private void btnAgregarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarFinalActionPerformed
        if(txtCodigoLista.getText().isEmpty()) {
           JOptionPane.showMessageDialog(null, "Por favor, colocar codigo");
      }
      else if (txtNombreLista.getText().isEmpty()){
           JOptionPane.showMessageDialog(null, "Por favor, colocar nombre");
      }
      else if(txtPrecioLista.getText().isEmpty()){
           JOptionPane.showMessageDialog(null, "Por favor, colocar precio");
      }else{
        nombreProducto = txtNombreLista.getText();
        idProductoAseo = Integer.parseInt(txtCodigoLista.getText());
        costoProducto = Double.parseDouble(txtPrecioLista.getText());
        
        alimentos = new AlimentosEstatico(nombreProducto,idProductoAseo,costoProducto);
        oAlimLista.agregarFinal(alimentos);
        try{
        JOptionPane.showMessageDialog(null, "Colocando producto al Final");
        
        txtMostrarLista.setText(oAlimLista.mostrarLista());
        
        vaciarDatosLista();
        }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error "+e.getMessage());
       }
      }
    }//GEN-LAST:event_btnAgregarFinalActionPerformed

    private void btnEliminarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarInicioActionPerformed
       try{
        JOptionPane.showMessageDialog(null, "Se ha eliminado del inicio el producto: \n"+oAlimLista.eliminarInicio().toString());
        txtMostrarLista.setText(oAlimLista.mostrarLista());
       }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error "+e.getMessage());
       }
    }//GEN-LAST:event_btnEliminarInicioActionPerformed

    private void btnEliminarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarFinalActionPerformed
        try{
        JOptionPane.showMessageDialog(null, "Se ha eliminado del final el producto: \n"+oAlimLista.eliminarFinal().toString());
        txtMostrarLista.setText(oAlimLista.mostrarLista());
       }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error "+e.getMessage());
       }
        
    }//GEN-LAST:event_btnEliminarFinalActionPerformed

    private void txtNombreListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreListaActionPerformed
              
    }//GEN-LAST:event_txtNombreListaActionPerformed

    private void btnGenerarLimiteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarLimiteActionPerformed
        if (txtLimProductos.getText().isEmpty()){
              JOptionPane.showMessageDialog(null, "Digite el tamaño", "AVISO", 
                    JOptionPane.INFORMATION_MESSAGE);
        } else{
        int valLimite;
       valLimite = Integer.parseInt(txtLimProductos.getText());
       oAlimLista.setNumLimite(valLimite);
       txtNombreLista.setEnabled(true);
        txtCodigoLista.setEnabled(true);
        txtPrecioLista.setEnabled(true);
        btnAgregarFinal.setEnabled(true);
        btnAgregarInicio.setEnabled(true);
        btnEliminarFinal.setEnabled(true);
        btnEliminarInicio.setEnabled(true);
        btnGenerarLimite.setEnabled(false);
        txtLimProductos.setEnabled(false);
        }
       
    }//GEN-LAST:event_btnGenerarLimiteActionPerformed

    private void txtLimProductosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtLimProductosKeyTyped
        // TODO add your handling code here:
         char car = evt.getKeyChar();
    if((car<'0' || car>'9')) evt.consume();
        
    }//GEN-LAST:event_txtLimProductosKeyTyped

    private void txtPrecioListaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioListaKeyTyped
       char car = evt.getKeyChar();
    if (((car < '0') || (car > '9')) && (car != KeyEvent.VK_BACK_SPACE)
                            && (car != '.') ) {
                        evt.consume();
                    }
    }//GEN-LAST:event_txtPrecioListaKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtCodigoListaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoListaKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
    if((car<'0' || car>'9')) evt.consume();
    }//GEN-LAST:event_txtCodigoListaKeyTyped
    
     public void vaciarDatosLista(){
        txtCodigoLista.setText("");
        txtNombreLista.setText("");
        txtPrecioLista.setText("");
    }
    
    public static boolean validarNumeros(String datos){
        return datos.matches("[0-9]*");
    }
    /**
     */

    
    /*public static void main(String[] args) {
            VentanaListaAl ventana = new VentanaListaAl();
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarFinal;
    private javax.swing.JButton btnAgregarInicio;
    private javax.swing.JButton btnEliminarFinal;
    private javax.swing.JButton btnEliminarInicio;
    private javax.swing.JButton btnGenerarLimite;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel lblCodigoL;
    private javax.swing.JLabel lblNombreL;
    private javax.swing.JLabel lblPrecioL;
    private javax.swing.JLabel titulo;
    private javax.swing.JTextField txtCodigoLista;
    private javax.swing.JTextField txtLimProductos;
    private javax.swing.JTextArea txtMostrarLista;
    private javax.swing.JTextField txtNombreLista;
    private javax.swing.JTextField txtPrecioLista;
    // End of variables declaration//GEN-END:variables
}
