
package pilas;


public class ProductosLimpieza {
    private int codigo;
    private String nombre;
    private double precio;
    private boolean descuento;
    private double precioFinal;
    private int cantDescuento;
    
    //CONSTRUCTOR
    public ProductosLimpieza(int codigo, String nombre, double precio, boolean descuento, int cantDescuento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.descuento = descuento;
        this.cantDescuento = cantDescuento;
    }
    
    //CONSTRUCTOR VACÍO
    public ProductosLimpieza() {
        this.codigo = 0;
        this.nombre = "";
        this.precio = 0.0;
    }
    
    //Método TOString
    @Override
     public String toString() {
        return " \n[ Código= " + codigo + ", Nombre= " + nombre + ", Precio= " + precio 
                + ", Descuento= "+ cantDescuento+"% , Precio Final = " + precioFinal + "]\n";
    }
    
    //
     public void calcularPrecio(){
        //double valDescuento;
        if (descuento==true){
            precioFinal=precio-precio*cantDescuento/100;
        }else{
            precioFinal=precio;
        }
    }
    
}
