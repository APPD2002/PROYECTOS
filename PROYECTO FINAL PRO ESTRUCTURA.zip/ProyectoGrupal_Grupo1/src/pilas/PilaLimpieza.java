
package pilas;

public class PilaLimpieza {
    ProductosLimpieza vectorPila[];
    int cima;//dato
    
/*
      ------  PRODUCTOS LIMPIEZA -----
    */    

//Construtor Productos Limpieza
    public PilaLimpieza(int tamanio){
        vectorPila=new ProductosLimpieza[tamanio];
        cima=-1;
    }
    
    //PuSh Productos Limpieza
    public void push (ProductosLimpieza dato){
    this.cima++;
    vectorPila[cima]=dato;
    }
    
    //PopProductos Limpieza
    public ProductosLimpieza pop(){
    ProductosLimpieza salir=vectorPila[cima];
    cima--;
    return salir;
    }
    
    //Conocer que elemento se encuentra cima
    public ProductosLimpieza cimaPila(){
    return vectorPila[cima];
    }
    

/*
    MÉTODOS GENERALES
    */

//sabe si la pila esta vacia
    public boolean estaVacia(){
    return cima== -1;
    }

    
    //Tamaño pila
    public int tamanioPila(){
    return vectorPila.length;
    }
    
    public boolean estaLlena(){
    return vectorPila.length-1==cima;
    
    }
    
    //Mostrar Todos los elementos
    public String mostrarElementos(){
        int cont = this.cima;
        String mostrar="..";
        for(int i=0;i<=cont;i++){
        mostrar="--> "+mostrar+vectorPila[i].toString()+".";
        }
       return mostrar;
    }
}
