
package pilas;


public class ProductosRopa {
    private int codigo;
    private String nombre;
    private int talla;
    private double precio;
    private boolean descuento;
    private double precioFinal;
    private int cantDescuento;
    
    
    
    //Constructor
    public ProductosRopa(int codigo, String nombre, int talla, double precio, boolean descuento, int cantDescuento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.talla = talla;
        this.precio = precio;
        this.descuento = descuento;
        this.cantDescuento = cantDescuento;
    }
    
    //CONSTRUCTOR VACÍO
     public ProductosRopa() {
        this.codigo = 0;
        this.nombre = null;
        this.talla = 0;
        this.precio = 0.0;
        
    }
     
     public void calcularPrecio(){
        //double valDescuento;
        if (descuento==true){
            precioFinal=precio-precio*cantDescuento/100;
        }else{
            precioFinal=precio;
        }
    }

    @Override
    public String toString() {
        return " \n[Código= " + codigo + ", Nombre= " + nombre + ", Talla= " + talla 
                + ", Precio= " + precio + "Descuento= "+cantDescuento+"% "+ "PrecioFinal= " + precioFinal;
    }
}
